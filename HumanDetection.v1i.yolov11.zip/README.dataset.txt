# Human Detection > 2025-08-10 10:52pm
https://universe.roboflow.com/walid-khan-dg6lu/human-detection-igx9z

Provided by a Roboflow user
License: CC BY 4.0

